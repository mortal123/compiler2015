int a  = {"abc", 1};


int main() {
    return 0;
}
