

int main() {
	int a[-100];
	return 0;
}