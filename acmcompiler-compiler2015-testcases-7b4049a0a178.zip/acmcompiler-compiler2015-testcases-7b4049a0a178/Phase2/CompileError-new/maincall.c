int main(int main) {
    /* The function has been overrided by parameter */
    main(7);
}
