int myFunc() = 0;
struct myStruct{
	int a();
}
int main(){
	char a = '\09';
}
