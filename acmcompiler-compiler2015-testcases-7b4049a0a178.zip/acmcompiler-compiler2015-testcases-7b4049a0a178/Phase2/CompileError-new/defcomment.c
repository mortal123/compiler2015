
int ab/*dfsdf*/c;	//手写lexer的时候为了图方便，曾经预先去掉了注释，导致这种情况可以过编译

int abc/*fsdfsdfsfd*/; //而这样是没有问题的

int main()
{
	return 0;
}
