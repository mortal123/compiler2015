
// 字符串转义符出错

int main() {
	printf("\x");
	return 0;
}

