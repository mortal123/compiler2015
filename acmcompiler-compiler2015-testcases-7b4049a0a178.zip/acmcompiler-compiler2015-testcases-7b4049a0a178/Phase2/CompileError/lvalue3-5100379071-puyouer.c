/**
 * func return can't be lvalue
 */

int main() {
    main() = 1;
}

