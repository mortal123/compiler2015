/** REMARK: Cannot define a void-type variable.
 *
**/

int main()
{
    void a;
}
