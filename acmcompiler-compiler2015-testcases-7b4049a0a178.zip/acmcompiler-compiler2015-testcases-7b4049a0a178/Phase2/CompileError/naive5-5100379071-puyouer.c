/*
 * naive
 */
struct A { int a; };

int main() {
    struct A a;
    if (a) {}
    return 0;
}
