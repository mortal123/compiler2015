/*
 * naive
 */
struct A {
    int a;
};

int main() {
    struct A a, b, c;
    c = a + b;
    return 0;
}
