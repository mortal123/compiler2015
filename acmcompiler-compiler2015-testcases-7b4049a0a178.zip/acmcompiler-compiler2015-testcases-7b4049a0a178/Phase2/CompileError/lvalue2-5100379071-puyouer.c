/**
 * 0 is not a lvalue
 */

int main() {
    int a, b;
    a = 0 = b;
}
