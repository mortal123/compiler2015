/**
 return type must be defined
 */

struct A {
    int x, y, z;
};

struct B f() {
    int a;
    a = 1;
}

int main() {
    return 0;
}
