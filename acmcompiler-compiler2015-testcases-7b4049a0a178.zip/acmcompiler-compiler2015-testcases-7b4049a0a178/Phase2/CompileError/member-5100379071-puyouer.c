/*
 * array doesn't have such member
 */
int main() {
    int a[10];
    int x;
    x = a.eee;
    return 0;
}
