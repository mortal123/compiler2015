/**
 string literal is not a lvalue
 */

int main() {
    int t;
    "a" = t;
}
