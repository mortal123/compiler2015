/*
break not within loop or switch
*/
int main() {
    while (1) { }
    break;
    return 0;
}
