/** REMARK: Arrays can not be assigned a value.
 *
**/

int a[4]={1};
int main()
{
    int b[4];
    a=b;
}
