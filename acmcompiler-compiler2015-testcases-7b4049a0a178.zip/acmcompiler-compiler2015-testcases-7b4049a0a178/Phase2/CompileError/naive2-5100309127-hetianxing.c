/*
 * conflicting type
 */
#include <stdio.h>
int b, c, d = 0 ,e = 0, f = 0;
char c;
int main() {
    int b;
}