/*
 * rename member in struct
 */
struct A {
    int f;
    char a, b, c, d, e, f, g;
};

int main() {
    return 0;
}
