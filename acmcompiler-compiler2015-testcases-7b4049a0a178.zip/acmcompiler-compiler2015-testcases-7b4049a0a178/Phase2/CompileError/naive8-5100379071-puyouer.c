/*
 * naive
 */
int main() {
    int a = 1;
    int x = a[1];
    return 0;
}
