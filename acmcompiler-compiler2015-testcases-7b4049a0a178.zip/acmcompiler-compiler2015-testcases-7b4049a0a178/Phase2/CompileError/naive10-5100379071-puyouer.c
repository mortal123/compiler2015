/*
 * naive
 */
struct A {
    int x, y, z;
};

int main() {
    char t;
    struct A x;
    t = x;
}
