/*
 * function argNumber mismatch
 */
int f(int a, int b) {
    return a + b;
}

int main() {
    int x;
    x = f(1, 2, 3);
    return 0;
}
