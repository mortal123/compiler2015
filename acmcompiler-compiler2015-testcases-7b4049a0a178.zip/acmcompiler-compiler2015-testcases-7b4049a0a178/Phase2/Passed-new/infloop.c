int main() {
    int i=0;
    for(;;) {
        i+=1;
        if(i==1)break;
    }
}