#include<stdio.h>

int a = 1 */*/*/ 2;

int main()
{
	printf("%d\n",a);
    return 0;
}
