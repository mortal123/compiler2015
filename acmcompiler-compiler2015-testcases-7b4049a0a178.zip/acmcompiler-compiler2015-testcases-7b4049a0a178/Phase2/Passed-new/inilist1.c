int a  = {1, "abc"};


int main() {
    return 0;
}