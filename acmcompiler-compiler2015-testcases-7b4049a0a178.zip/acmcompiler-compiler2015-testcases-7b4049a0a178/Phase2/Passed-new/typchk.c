char s[10] = {'a' + 1, 'b', 'c'};
int * a, * b;
void * va, * vb;
int ia, ib;
void g(int a[8]) {

}
int main() {
	int aa[2][3][4];
	int x;
	a = aa;
	ia = aa;
	g(a);
	va < a;
	a < b;
	a > b;
	a <= b;
	a >= b;
	va <= vb;
	va >= vb;
	va < vb;
	va > vb;
	va + ia;
	va - ib;
	va += ia;
	va -= ia;
	a + ia;
	a - ib;
	a += ia;
	a -= ib;
	va - vb;
	a - b;
	a -= b;

	ia - 'a';
	va -= vb;
	!va;
	!a;
	a = &x;
	va = a;
	va ++;
	"abc"[0];
	"abc"[0] = 1;
	sizeof a;
	sizeof(void *);
}
