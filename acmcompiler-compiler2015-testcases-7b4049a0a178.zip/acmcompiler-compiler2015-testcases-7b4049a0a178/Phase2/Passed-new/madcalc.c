#include<stdio.h>
char *_ = "#include <stdio.h>%cchar* recurse=%c%s%c;%cint main(){printf(recurse,10,34,recurse,34,10,10);}%c";
int M[5000]={2},*u=M,N[5000],R=22,a[4],l[5]={0,-1,39-1,-1},m[4]={1,-39,-1,39},*b=N,
*d=N,c,e,f,g,i,j,k,s;int main(){for(M[i=39*R-1]=24;f|d>=b;){c=M[g=i];i=e;for(s=f=0;
s<4;s++)if((k=m[s]+g)>=0&&k<39*R&&l[s]!=k%39&&(!M[k]||!j&&c>=16!=M[k]>=16))a[f++
]=s;if(f){f=M[e=m[s=a[1/(1+2147483647/f)]]+g];if(j < f) j=f;f+=c&-16*!j;M[g]=
c|1<<s;M[*d++=e]=f|1<<(s+2)%4;}else if(d > b++) e=b[-1];}printf(" ");for(s=39;--s;printf("_")
)printf(" "); for(;printf("\n"),R--;printf("|"))for(e=39;e--;printf("%c", *("_ "+(*u++/8)%2)))printf("%c", *("| "+(*u/4)%2
		));}
