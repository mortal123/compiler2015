int main()
{
    int a[5], i;
    for(i = 0; i <= 6; ++i)
    {
        a[i] = i;
    }
    return 0;
}