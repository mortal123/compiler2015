int f(int anything) {
	return 0;
}

int main() {
  int x = f(x);
  printf("%d\n", x);
  return x;
}
