#include <stdio.h>
char*f="#include <stdio.h>%cchar*f=%c%s%c;int main(){printf(f,10,34,f,34,10);}%c";int main(){printf(f,10,34,f,34,10);}
