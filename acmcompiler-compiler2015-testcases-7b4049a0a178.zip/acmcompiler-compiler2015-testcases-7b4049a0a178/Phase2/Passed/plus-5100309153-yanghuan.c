#include <stdio.h>

int main()
{
    int i = 10283;
    printf("%d", 1 + 2 + i);
    printf("\n");
    printf("%d", 3 * 5);
    printf("\n");
    printf("%d", 6 / 2);
    printf("\n");
    return 0;
}
